#!/bin/bash
set -e

# Diretório onde os arquivos originais de backup estão salvos
SRC_DIR="/usr/share/issue-files-backup"

if [ -d "$SRC_DIR" ]; then
    for file in "$SRC_DIR"/issue*; do
        if [ -f "$file" ]; then
            filename=$(basename "$file")
            # Escreve/sobrescreve o conteúdo no /etc/ correspondente
            cat "$file" > "/etc/$filename"
            echo "Restaurado: /etc/$filename"
        fi
    done
fi
